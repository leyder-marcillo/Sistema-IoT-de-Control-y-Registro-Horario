function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

const eventLabels = {
  entrada: 'Entrada',
  salida: 'Salida',
  acceso_area: 'Acceso área',
  denegado_area: 'Denegado área',
  denegado: 'Denegado',
  acceso: 'Acceso'
};

function statusBadge(result) {
  if (result === 'PERMITIDO') return '<span class="status-badge success">Permitido</span>';
  return '<span class="status-badge danger">Denegado</span>';
}

function renderLogs(items) {
  const body = document.getElementById('logsBody');
  if (!body) return;
  if (!items || items.length === 0) {
    body.innerHTML = '<tr><td colspan="7" class="empty-state">No hay registros para mostrar.</td></tr>';
    return;
  }
  body.innerHTML = items.map(item => `
    <tr>
      <td>${escapeHtml(item.created_at)}</td>
      <td>${escapeHtml(item.employee)}</td>
      <td><code>${escapeHtml(item.uid_rfid)}</code></td>
      <td>${escapeHtml(item.door_name)}</td>
      <td>${escapeHtml(eventLabels[item.event_type] || item.event_type || '-')}</td>
      <td>${statusBadge(item.result)}</td>
      <td>${escapeHtml(item.message)}</td>
    </tr>
  `).join('');
}

async function refreshLogs() {
  const params = new URLSearchParams(window.location.search);
  try {
    const response = await fetch(`/api/registros?${params.toString()}`, {cache: 'no-store'});
    if (!response.ok) return;
    renderLogs(await response.json());
  } catch (error) {
    console.warn('No se pudo actualizar registros', error);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  refreshLogs();
  setInterval(refreshLogs, 2500);
});
