let lastEventId = 0;

const eventLabels = {
  entrada: 'Entrada',
  salida: 'Salida',
  acceso_area: 'Acceso',
  denegado_area: 'Denegado',
  denegado: 'Denegado',
  acceso: 'Acceso'
};

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function statusBadge(result) {
  if (result === 'PERMITIDO') return '<span class="status-badge success">Permitido</span>';
  return '<span class="status-badge danger">Denegado</span>';
}

function updateMetric(name, value) {
  const node = document.querySelector(`[data-metric="${name}"]`);
  if (!node) return;
  const oldValue = node.textContent.trim();
  const newValue = String(value ?? 0);
  if (oldValue !== newValue) {
    node.textContent = newValue;
    node.closest('.metric-card')?.classList.add('pulse');
    setTimeout(() => node.closest('.metric-card')?.classList.remove('pulse'), 600);
  }
}

function renderLatestLogs(items) {
  const body = document.getElementById('latestLogsBody');
  if (!body) return;
  if (!items || items.length === 0) {
    body.innerHTML = '<tr><td colspan="5" class="empty-state">Aún no hay registros.</td></tr>';
    return;
  }
  body.innerHTML = items.map(item => `
    <tr>
      <td>${escapeHtml(item.created_at)}</td>
      <td>${escapeHtml(item.employee)}</td>
      <td>${escapeHtml(item.door_name)}</td>
      <td>${escapeHtml(eventLabels[item.event_type] || item.event_type || '-')}</td>
      <td>${statusBadge(item.result)}</td>
    </tr>
  `).join('');
}

function renderHours(summary) {
  const body = document.getElementById('hoursBody');
  const label = document.getElementById('hoursSummaryLabel');
  if (!body) return;
  if (label) label.textContent = summary?.label || '';
  const items = summary?.items || [];
  if (items.length === 0) {
    body.innerHTML = '<tr><td colspan="4" class="empty-state">Sin horas registradas en este periodo.</td></tr>';
    return;
  }
  body.innerHTML = items.map(item => `
    <tr>
      <td>${escapeHtml(item.employee)}</td>
      <td><strong>${escapeHtml(item.duration)}</strong></td>
      <td>${escapeHtml(item.sessions)}</td>
      <td>${item.open ? '<span class="status-badge info">En empresa</span>' : '<span class="status-badge neutral">Cerrado</span>'}</td>
    </tr>
  `).join('');
}

function renderRestricted(items) {
  const body = document.getElementById('restrictedBody');
  if (!body) return;
  if (!items || items.length === 0) {
    body.innerHTML = '<tr><td colspan="4" class="empty-state">No hay ingresos registrados para este día.</td></tr>';
    return;
  }
  body.innerHTML = items.map(item => `
    <tr>
      <td>${escapeHtml(item.time)}</td>
      <td>${escapeHtml(item.employee)}</td>
      <td><code>${escapeHtml(item.uid_rfid)}</code></td>
      <td><span class="status-badge success">Permitido</span></td>
    </tr>
  `).join('');
}

function currentParams() {
  const employeeId = document.getElementById('employeeFilter')?.value || '0';
  const period = document.getElementById('periodFilter')?.value || 'day';
  const date = document.getElementById('dateFilter')?.value || '';
  const restrictedDate = document.getElementById('restrictedDateFilter')?.value || '';

  const params = new URLSearchParams();
  params.set('period', period);
  if (date) params.set('date', date);
  if (employeeId && employeeId !== '0') params.set('employee_id', employeeId);
  if (restrictedDate) params.set('restricted_date', restrictedDate);
  return params.toString();
}

async function refreshDashboard() {
  try {
    const response = await fetch(`/api/dashboard?${currentParams()}`, {cache: 'no-store'});
    if (!response.ok) return;
    const data = await response.json();

    Object.entries(data.metrics || {}).forEach(([key, value]) => updateMetric(key, value));
    renderLatestLogs(data.latest_logs || []);
    renderHours(data.attendance_summary || {});
    renderRestricted(data.restricted_logs || []);

    if (lastEventId && data.last_event_id && data.last_event_id !== lastEventId) {
      document.body.classList.add('new-event');
      setTimeout(() => document.body.classList.remove('new-event'), 800);
    }
    lastEventId = data.last_event_id || lastEventId;
  } catch (error) {
    console.warn('No se pudo actualizar el dashboard', error);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  ['employeeFilter', 'periodFilter', 'dateFilter', 'restrictedDateFilter'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', refreshDashboard);
  });
  refreshDashboard();
  setInterval(refreshDashboard, 2000);
});
