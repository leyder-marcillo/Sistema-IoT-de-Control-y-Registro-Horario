# Instalación en Raspberry Pi

Esta versión está preparada para correr en la Raspberry Pi y conectarse al Mosquitto local con MQTTS/TLS usando certificados en `~/mqtt_certs`.

## 1. Copiar proyecto a la Raspberry

Se recomienda dejarlo en:

```bash
~/iot_aplicacion_json_tls
```

## 2. Verificar certificados

En la Raspberry:

```bash
ls -l ~/mqtt_certs
```

La app espera estos tres archivos por defecto:

```text
~/mqtt_certs/ca.crt
~/mqtt_certs/client.crt
~/mqtt_certs/client.key
```

Si los archivos tienen otros nombres, edita `.env`.

## 3. Configuración `.env`

```env
MQTT_ENABLED=1
MQTT_HOST=localhost
MQTT_PORT=8883
MQTT_TOPIC_IN=test/esp32
MQTT_TOPIC_OUT=esp32/ordenes
MQTT_TLS=1
MQTT_TLS_INSECURE=1
MQTT_CA_CERT=~/mqtt_certs/ca.crt
MQTT_CLIENT_CERT=~/mqtt_certs/client.crt
MQTT_CLIENT_KEY=~/mqtt_certs/client.key

MAIN_DOOR_DEVICE_ID=F4:65:0B:54:89:1C
RESTRICTED_DOOR_DEVICE_ID=78:42:1C:6C:0F:B0
```

La aplicación muestra esos dispositivos como:

```text
F4:65:0B:54:89:1C -> Puerta Principal
78:42:1C:6C:0F:B0 -> Área Restringida
```

## 4. Instalar dependencias

```bash
cd ~/iot_aplicacion_json_tls
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
nano .env
```

## 5. Probar manualmente

```bash
source venv/bin/activate
python app.py
```

Desde el computador, abre:

```text
http://IP_DE_LA_RASPBERRY:5000
```

Credenciales iniciales:

```text
admin / admin123
```

## 6. Probar MQTT local

Terminal 1 en la Raspberry, para ver la respuesta de la app:

```bash
mosquitto_sub -h localhost -p 8883 \
  --cafile ~/mqtt_certs/ca.crt \
  --cert ~/mqtt_certs/client.crt \
  --key ~/mqtt_certs/client.key \
  --insecure \
  -t esp32/ordenes -v
```

Terminal 2 en la Raspberry, para simular la ESP32 en Puerta Principal:

```bash
mosquitto_pub -h localhost -p 8883 \
  --cafile ~/mqtt_certs/ca.crt \
  --cert ~/mqtt_certs/client.crt \
  --key ~/mqtt_certs/client.key \
  --insecure \
  -t test/esp32 \
  -m '{"uid":"59 EF A0 03","authorized":false,"door_state":"closed","device_id":"F4:65:0B:54:89:1C"}'
```

Si el UID existe, la primera lectura en Puerta Principal registra entrada. La siguiente lectura del mismo UID registra salida y calcula horas efectivas.

Para probar Área Restringida:

```bash
mosquitto_pub -h localhost -p 8883 \
  --cafile ~/mqtt_certs/ca.crt \
  --cert ~/mqtt_certs/client.crt \
  --key ~/mqtt_certs/client.key \
  --insecure \
  -t test/esp32 \
  -m '{"uid":"59 EF A0 03","authorized":false,"door_state":"closed","device_id":"78:42:1C:6C:0F:B0"}'
```

## 7. Iniciar automáticamente con systemd

```bash
cd ~/iot_aplicacion_json_tls
chmod +x deploy/install_raspberry.sh
./deploy/install_raspberry.sh
```

Comandos útiles:

```bash
sudo systemctl status iot-app.service
sudo systemctl restart iot-app.service
sudo journalctl -u iot-app.service -f
```

Para verificar Mosquitto:

```bash
sudo systemctl status mosquitto
sudo journalctl -u mosquitto -f
```
