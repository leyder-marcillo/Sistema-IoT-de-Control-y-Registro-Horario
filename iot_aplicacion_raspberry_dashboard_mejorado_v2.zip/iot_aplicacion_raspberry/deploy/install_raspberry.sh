#!/usr/bin/env bash
set -e

APP_DIR="${APP_DIR:-$HOME/iot_aplicacion_json_tls}"
SERVICE_NAME="iot-app.service"

cd "$APP_DIR"
python3 -m venv venv
./venv/bin/python -m pip install --upgrade pip
./venv/bin/pip install -r requirements.txt

if [ ! -f .env ]; then
  cp .env.example .env
  echo "Se creó .env desde .env.example. Revísalo antes de iniciar el servicio."
fi

USER_NAME="$(whoami)"
SERVICE_PATH="/etc/systemd/system/$SERVICE_NAME"

sed \
  -e "s|User=pi|User=$USER_NAME|" \
  -e "s|WorkingDirectory=/home/pi/iot_aplicacion_json_tls|WorkingDirectory=$APP_DIR|" \
  -e "s|EnvironmentFile=/home/pi/iot_aplicacion_json_tls/.env|EnvironmentFile=$APP_DIR/.env|" \
  -e "s|ExecStart=/home/pi/iot_aplicacion_json_tls/venv/bin/python /home/pi/iot_aplicacion_json_tls/app.py|ExecStart=$APP_DIR/venv/bin/python $APP_DIR/app.py|" \
  deploy/iot-app.service | sudo tee "$SERVICE_PATH" > /dev/null

sudo systemctl daemon-reload
sudo systemctl enable iot-app.service
sudo systemctl restart iot-app.service

echo "Servicio instalado. Estado:"
sudo systemctl status iot-app.service --no-pager
