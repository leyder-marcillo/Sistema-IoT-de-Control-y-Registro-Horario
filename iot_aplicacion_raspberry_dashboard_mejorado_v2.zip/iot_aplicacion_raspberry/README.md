# IoT Registro Horario - Capa de aplicación

Aplicación Flask para Raspberry Pi que centraliza la capa de aplicación del sistema IoT de control y registro horario.

## Funciones principales

- Recibe eventos JSON desde MQTT en `test/esp32`.
- Valida el UID RFID contra la base de datos de empleados.
- Responde al ESP32 por `esp32/ordenes` con JSON de autorización.
- Diferencia dos puertas por `device_id`:
  - `F4:65:0B:54:89:1C` → Puerta Principal.
  - `78:42:1C:6C:0F:B0` → Área Restringida.
- En Puerta Principal registra entrada/salida y calcula horas efectivas.
- En Área Restringida registra únicamente quién ingresó y a qué hora.
- Dashboard con actualización automática sin recargar la página.
- Gestión de empleados y autorización para Área Restringida.

## Credenciales iniciales

```text
Usuario: admin
Contraseña: admin123
```

## Instalación rápida en Raspberry Pi

```bash
cd ~/iot_aplicacion_json_tls
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
nano .env
python app.py
```

Abrir desde el computador:

```text
http://IP_DE_LA_RASPBERRY:5000
```

## Inicio automático

```bash
cd ~/iot_aplicacion_json_tls
chmod +x deploy/install_raspberry.sh
./deploy/install_raspberry.sh
```

Ver estado:

```bash
sudo systemctl status iot-app.service
sudo journalctl -u iot-app.service -f
```
