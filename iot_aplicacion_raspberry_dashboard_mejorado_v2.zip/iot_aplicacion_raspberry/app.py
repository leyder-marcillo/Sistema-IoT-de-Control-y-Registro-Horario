import json
import ssl
from collections import defaultdict
from datetime import date, datetime, time, timedelta
from typing import Any, Dict, List, Optional, Tuple

import paho.mqtt.client as mqtt
from flask import Flask, flash, jsonify, redirect, render_template, request, url_for
from flask_login import LoginManager, UserMixin, current_user, login_required, login_user, logout_user
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import or_, text
from werkzeug.security import check_password_hash, generate_password_hash

from config import Config


db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = "login"

mqtt_client: Optional[mqtt.Client] = None


class SystemUser(UserMixin, db.Model):
    __tablename__ = "system_users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(30), default="admin", nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)


class Employee(db.Model):
    __tablename__ = "employees"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    document = db.Column(db.String(40), nullable=True)
    uid_rfid = db.Column(db.String(40), unique=True, nullable=False, index=True)
    position = db.Column(db.String(100), nullable=True)
    active = db.Column(db.Boolean, default=True, nullable=False)
    restricted_access = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)

    logs = db.relationship("AccessLog", back_populates="employee", lazy=True)
    attendance_sessions = db.relationship("AttendanceSession", back_populates="employee", lazy=True)


class AccessLog(db.Model):
    __tablename__ = "access_logs"

    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey("employees.id"), nullable=True)
    uid_rfid = db.Column(db.String(40), nullable=False, index=True)
    result = db.Column(db.String(20), nullable=False)  # PERMITIDO / DENEGADO
    message = db.Column(db.String(120), nullable=False)
    source = db.Column(db.String(20), default="mqtt", nullable=False)  # mqtt / web
    device_id = db.Column(db.String(80), nullable=True)
    door_name = db.Column(db.String(80), nullable=True)
    door_state = db.Column(db.String(30), nullable=True)
    event_type = db.Column(db.String(40), nullable=True)  # entrada / salida / acceso_area / denegado
    raw_payload = db.Column(db.Text, nullable=True)
    response_payload = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False, index=True)

    employee = db.relationship("Employee", back_populates="logs")


class AttendanceSession(db.Model):
    __tablename__ = "attendance_sessions"

    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey("employees.id"), nullable=False, index=True)
    check_in = db.Column(db.DateTime, nullable=False, index=True)
    check_out = db.Column(db.DateTime, nullable=True, index=True)
    duration_seconds = db.Column(db.Integer, default=0, nullable=False)
    device_id = db.Column(db.String(80), nullable=True)
    door_name = db.Column(db.String(80), default="Puerta Principal", nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)

    employee = db.relationship("Employee", back_populates="attendance_sessions")


@login_manager.user_loader
def load_user(user_id: str) -> Optional[SystemUser]:
    return db.session.get(SystemUser, int(user_id))


def normalize_uid(uid: str) -> str:
    """Normaliza el UID: quita espacios, guiones, dos puntos y pasa a mayúsculas."""
    return "".join(ch for ch in str(uid or "").strip().upper() if ch.isalnum())


def format_uid(uid_clean: str) -> str:
    """Devuelve el UID normalizado en grupos de dos caracteres: 59 EF A0 03."""
    uid_clean = normalize_uid(uid_clean)
    return " ".join(uid_clean[i:i + 2] for i in range(0, len(uid_clean), 2))


def normalize_device_id(device_id: Optional[str]) -> str:
    return str(device_id or "").strip().upper()


def device_map() -> Dict[str, str]:
    return {
        normalize_device_id(Config.MAIN_DOOR_DEVICE_ID): "Puerta Principal",
        normalize_device_id(Config.RESTRICTED_DOOR_DEVICE_ID): "Área Restringida",
    }


def get_door_name(device_id: Optional[str]) -> str:
    device_id_norm = normalize_device_id(device_id)
    if not device_id_norm:
        return "Puerta no identificada"
    return device_map().get(device_id_norm, "Puerta no identificada")


def get_door_type(device_id: Optional[str]) -> str:
    device_id_norm = normalize_device_id(device_id)
    if device_id_norm == normalize_device_id(Config.MAIN_DOOR_DEVICE_ID):
        return "main"
    if device_id_norm == normalize_device_id(Config.RESTRICTED_DOOR_DEVICE_ID):
        return "restricted"
    return "unknown"


def parse_mqtt_payload(payload: str) -> Dict[str, Any]:
    """
    Acepta dos formatos:
    1) UID plano: 59EFA003
    2) JSON: {"uid":"59 EF A0 03", "device_id":"F4:65:0B:54:89:1C", "door_state":"closed"}
    """
    payload = payload.strip()
    if not payload:
        return {"uid": "", "raw": payload, "is_json": False}

    try:
        data = json.loads(payload)
        if isinstance(data, dict):
            data["raw"] = payload
            data["is_json"] = True
            return data
    except json.JSONDecodeError:
        pass

    return {"uid": payload, "raw": payload, "is_json": False}


def build_response_payload(uid: str, allowed: bool, device_id: Optional[str], message: Optional[str] = None) -> Dict[str, Any]:
    """Construye la orden JSON que recibe el ESP32 por el tópico esp32/ordenes."""
    return {
        "uid": format_uid(uid),
        "authorized": bool(allowed),
        "door_state": "open" if allowed else "closed",
        "device_id": device_id or "esp32_access_01",
        "message": message or ("ACCESO PERMITIDO" if allowed else "ACCESO DENEGADO"),
    }


def current_open_session(employee_id: int) -> Optional[AttendanceSession]:
    return (
        AttendanceSession.query
        .filter_by(employee_id=employee_id, check_out=None)
        .order_by(AttendanceSession.check_in.desc())
        .first()
    )


def validate_and_register_uid(
    uid: str,
    source: str = "mqtt",
    device_id: Optional[str] = None,
    incoming_door_state: Optional[str] = None,
    raw_payload: Optional[str] = None,
) -> Tuple[bool, str, AccessLog, Dict[str, Any]]:
    """Valida el UID, registra evento, gestiona jornada y retorna la respuesta JSON."""
    uid_clean = normalize_uid(uid)
    device_id_raw = str(device_id or "").strip() or None
    door_name = get_door_name(device_id_raw)
    door_type = get_door_type(device_id_raw)
    now = datetime.now()

    employee = Employee.query.filter_by(uid_rfid=uid_clean, active=True).first() if uid_clean else None
    allowed = employee is not None
    event_type = "denegado"
    message = "ACCESO DENEGADO"

    if door_type == "restricted":
        allowed = bool(employee and employee.restricted_access)
        if allowed:
            event_type = "acceso_area"
            message = "ACCESO PERMITIDO"
        else:
            event_type = "denegado_area"
            message = "ACCESO DENEGADO"

    elif door_type == "main":
        if allowed and employee:
            open_session = current_open_session(employee.id)
            if open_session:
                open_session.check_out = now
                open_session.duration_seconds = max(0, int((open_session.check_out - open_session.check_in).total_seconds()))
                event_type = "salida"
                message = "SALIDA REGISTRADA"
            else:
                db.session.add(AttendanceSession(
                    employee_id=employee.id,
                    check_in=now,
                    device_id=device_id_raw,
                    door_name="Puerta Principal",
                ))
                event_type = "entrada"
                message = "ENTRADA REGISTRADA"
        else:
            allowed = False
            event_type = "denegado"
            message = "ACCESO DENEGADO"

    else:
        # Si llega un equipo no mapeado, no se altera la jornada laboral.
        # Se valida el UID para conservar compatibilidad, pero se marca la puerta como no identificada.
        if allowed:
            event_type = "acceso"
            message = "ACCESO PERMITIDO"
        else:
            event_type = "denegado"
            message = "ACCESO DENEGADO"

    result = "PERMITIDO" if allowed else "DENEGADO"
    response_payload = build_response_payload(uid_clean or uid, allowed, device_id_raw, message)

    log = AccessLog(
        employee_id=employee.id if employee else None,
        uid_rfid=uid_clean or "UID_VACIO",
        result=result,
        message=message,
        source=source,
        device_id=device_id_raw,
        door_name=door_name,
        door_state=response_payload["door_state"],
        event_type=event_type,
        raw_payload=raw_payload,
        response_payload=json.dumps(response_payload, ensure_ascii=False),
    )
    db.session.add(log)
    db.session.commit()

    return allowed, message, log, response_payload


def publish_order(payload: Dict[str, Any]) -> None:
    """Publica la orden/respuesta hacia el ESP32 en formato JSON."""
    global mqtt_client
    if mqtt_client is None:
        print("[MQTT] Cliente no inicializado. No se pudo publicar la orden.")
        return

    topic_out = current_app_config("MQTT_TOPIC_OUT")
    message = json.dumps(payload, ensure_ascii=False)
    mqtt_client.publish(topic_out, message)
    print(f"[MQTT] Publicado en {topic_out}: {message}")


def current_app_config(key: str):
    from flask import current_app

    return current_app.config[key]


def period_range(period: str, selected_date: Optional[str]) -> Tuple[datetime, datetime, str]:
    try:
        base_date = datetime.strptime(selected_date, "%Y-%m-%d").date() if selected_date else date.today()
    except ValueError:
        base_date = date.today()

    period = (period or "day").lower()
    if period == "week":
        start_day = base_date - timedelta(days=base_date.weekday())
        end_day = start_day + timedelta(days=7)
        label = f"Semana del {start_day.strftime('%Y-%m-%d')}"
    elif period == "month":
        start_day = base_date.replace(day=1)
        if start_day.month == 12:
            end_day = start_day.replace(year=start_day.year + 1, month=1)
        else:
            end_day = start_day.replace(month=start_day.month + 1)
        label = start_day.strftime("%B %Y").capitalize()
    else:
        start_day = base_date
        end_day = start_day + timedelta(days=1)
        label = start_day.strftime("%Y-%m-%d")

    return datetime.combine(start_day, time.min), datetime.combine(end_day, time.min), label


def format_duration(seconds: int) -> str:
    seconds = max(0, int(seconds or 0))
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    return f"{hours} h {minutes:02d} min"


def session_overlap_seconds(session: AttendanceSession, start: datetime, end: datetime, now: Optional[datetime] = None) -> int:
    now = now or datetime.now()
    session_end = session.check_out or now
    effective_start = max(session.check_in, start)
    effective_end = min(session_end, end)
    if effective_end <= effective_start:
        return 0
    return int((effective_end - effective_start).total_seconds())


def worked_hours_summary(period: str = "day", selected_date: Optional[str] = None, employee_id: Optional[int] = None) -> Dict[str, Any]:
    start, end, label = period_range(period, selected_date)
    query = AttendanceSession.query.join(Employee).filter(
        AttendanceSession.check_in < end,
        or_(AttendanceSession.check_out == None, AttendanceSession.check_out > start),  # noqa: E711
    )
    if employee_id:
        query = query.filter(AttendanceSession.employee_id == employee_id)

    rows: Dict[int, Dict[str, Any]] = {}
    now = datetime.now()
    for session in query.order_by(AttendanceSession.check_in.asc()).all():
        seconds = session_overlap_seconds(session, start, end, now)
        if seconds <= 0:
            continue
        item = rows.setdefault(session.employee_id, {
            "employee_id": session.employee_id,
            "employee": session.employee.name,
            "seconds": 0,
            "sessions": 0,
            "open": False,
        })
        item["seconds"] += seconds
        item["sessions"] += 1
        item["open"] = item["open"] or session.check_out is None

    items = []
    for item in rows.values():
        item["hours"] = round(item["seconds"] / 3600, 2)
        item["duration"] = format_duration(item["seconds"])
        items.append(item)

    items.sort(key=lambda x: x["employee"])
    return {
        "period": period,
        "start": start.strftime("%Y-%m-%d"),
        "end": end.strftime("%Y-%m-%d"),
        "label": label,
        "items": items,
    }


def restricted_access_for_day(selected_date: Optional[str] = None) -> List[AccessLog]:
    start, end, _label = period_range("day", selected_date)
    return (
        AccessLog.query
        .filter(
            AccessLog.created_at >= start,
            AccessLog.created_at < end,
            AccessLog.door_name == "Área Restringida",
            AccessLog.result == "PERMITIDO",
        )
        .order_by(AccessLog.created_at.desc())
        .limit(100)
        .all()
    )


def metrics_for_today() -> Dict[str, Any]:
    today_start = datetime.combine(date.today(), datetime.min.time())
    return {
        "total_employees": Employee.query.count(),
        "active_employees": Employee.query.filter_by(active=True).count(),
        "inside_now": AttendanceSession.query.filter(AttendanceSession.check_out == None).count(),  # noqa: E711
        "allowed_today": AccessLog.query.filter(AccessLog.created_at >= today_start, AccessLog.result == "PERMITIDO").count(),
        "denied_today": AccessLog.query.filter(AccessLog.created_at >= today_start, AccessLog.result == "DENEGADO").count(),
        "restricted_today": AccessLog.query.filter(
            AccessLog.created_at >= today_start,
            AccessLog.door_name == "Área Restringida",
            AccessLog.result == "PERMITIDO",
        ).count(),
    }


def serialize_log(item: AccessLog) -> Dict[str, Any]:
    return {
        "id": item.id,
        "uid_rfid": format_uid(item.uid_rfid),
        "employee": item.employee.name if item.employee else "No registrado",
        "result": item.result,
        "message": item.message,
        "source": item.source,
        "door_name": item.door_name or get_door_name(item.device_id),
        "door_state": item.door_state,
        "event_type": item.event_type or "-",
        "created_at": item.created_at.strftime("%Y-%m-%d %H:%M:%S"),
        "time": item.created_at.strftime("%H:%M:%S"),
    }


def create_app() -> Flask:
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    login_manager.init_app(app)

    register_routes(app)

    with app.app_context():
        db.create_all()
        ensure_schema_updates()
        seed_initial_data()

    return app


def ensure_schema_updates() -> None:
    """Agrega columnas nuevas si ya existía una base de datos de versiones anteriores."""
    # Migraciones de access_logs
    access_columns = {row[1] for row in db.session.execute(text("PRAGMA table_info(access_logs)")).fetchall()}
    access_migrations = {
        "device_id": "ALTER TABLE access_logs ADD COLUMN device_id VARCHAR(80)",
        "door_name": "ALTER TABLE access_logs ADD COLUMN door_name VARCHAR(80)",
        "door_state": "ALTER TABLE access_logs ADD COLUMN door_state VARCHAR(30)",
        "event_type": "ALTER TABLE access_logs ADD COLUMN event_type VARCHAR(40)",
        "raw_payload": "ALTER TABLE access_logs ADD COLUMN raw_payload TEXT",
        "response_payload": "ALTER TABLE access_logs ADD COLUMN response_payload TEXT",
    }
    for column, ddl in access_migrations.items():
        if column not in access_columns:
            db.session.execute(text(ddl))

    # Migraciones de employees
    employee_columns = {row[1] for row in db.session.execute(text("PRAGMA table_info(employees)")).fetchall()}
    if "restricted_access" not in employee_columns:
        db.session.execute(text("ALTER TABLE employees ADD COLUMN restricted_access BOOLEAN DEFAULT 0 NOT NULL"))

    # Completa nombres de puerta en registros antiguos, si se puede inferir.
    db.session.execute(text(
        "UPDATE access_logs SET door_name = 'Puerta Principal' "
        "WHERE door_name IS NULL AND UPPER(device_id) = :device"
    ), {"device": normalize_device_id(Config.MAIN_DOOR_DEVICE_ID)})
    db.session.execute(text(
        "UPDATE access_logs SET door_name = 'Área Restringida' "
        "WHERE door_name IS NULL AND UPPER(device_id) = :device"
    ), {"device": normalize_device_id(Config.RESTRICTED_DOOR_DEVICE_ID)})

    db.session.commit()


def seed_initial_data() -> None:
    """Crea usuario administrador y dos tarjetas de prueba."""
    if SystemUser.query.count() == 0:
        admin = SystemUser(username="admin", role="admin")
        admin.set_password("admin123")
        db.session.add(admin)

    if Employee.query.count() == 0:
        employees = [
            Employee(
                name="Johan David Rojas Martinez",
                document="",
                uid_rfid="59EFA003",
                position="Integrante del proyecto",
                active=True,
                restricted_access=True,
            ),
            Employee(
                name="Empleado Tarjeta 2",
                document="",
                uid_rfid="A1B2C3D4",
                position="Tarjeta de prueba - cambiar UID real",
                active=True,
                restricted_access=False,
            ),
        ]
        db.session.add_all(employees)

    db.session.commit()


def register_routes(app: Flask) -> None:
    @app.route("/")
    def index():
        if current_user.is_authenticated:
            return redirect(url_for("dashboard"))
        return redirect(url_for("login"))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            user = SystemUser.query.filter_by(username=username).first()

            if user and user.check_password(password):
                login_user(user)
                return redirect(url_for("dashboard"))

            flash("Usuario o contraseña incorrectos.", "danger")

        return render_template("login.html")

    @app.route("/logout")
    @login_required
    def logout():
        logout_user()
        return redirect(url_for("login"))

    @app.route("/dashboard")
    @login_required
    def dashboard():
        employees = Employee.query.filter_by(active=True).order_by(Employee.name.asc()).all()
        period = request.args.get("period", "day")
        selected_date = request.args.get("date", date.today().strftime("%Y-%m-%d"))
        employee_id = request.args.get("employee_id", type=int)
        restricted_date = request.args.get("restricted_date", date.today().strftime("%Y-%m-%d"))

        return render_template(
            "dashboard.html",
            metrics=metrics_for_today(),
            latest_logs=AccessLog.query.order_by(AccessLog.created_at.desc()).limit(8).all(),
            employees=employees,
            selected_period=period,
            selected_date=selected_date,
            selected_employee_id=employee_id or 0,
            restricted_date=restricted_date,
            attendance_summary=worked_hours_summary(period, selected_date, employee_id),
            restricted_logs=restricted_access_for_day(restricted_date),
        )

    @app.route("/empleados")
    @login_required
    def employees():
        items = Employee.query.order_by(Employee.name.asc()).all()
        return render_template("employees.html", employees=items)

    @app.route("/empleados/nuevo", methods=["GET", "POST"])
    @login_required
    def new_employee():
        if request.method == "POST":
            return save_employee()
        return render_template("employee_form.html", employee=None)

    @app.route("/empleados/<int:employee_id>/editar", methods=["GET", "POST"])
    @login_required
    def edit_employee(employee_id: int):
        employee = db.session.get(Employee, employee_id)
        if employee is None:
            flash("Empleado no encontrado.", "warning")
            return redirect(url_for("employees"))

        if request.method == "POST":
            return save_employee(employee)

        return render_template("employee_form.html", employee=employee)

    def save_employee(employee: Optional[Employee] = None):
        name = request.form.get("name", "").strip()
        document = request.form.get("document", "").strip()
        uid_rfid = normalize_uid(request.form.get("uid_rfid", ""))
        position = request.form.get("position", "").strip()
        active = request.form.get("active") == "on"
        restricted_access = request.form.get("restricted_access") == "on"

        if not name or not uid_rfid:
            flash("El nombre y el UID RFID son obligatorios.", "danger")
            return redirect(request.url)

        duplicated = Employee.query.filter_by(uid_rfid=uid_rfid).first()
        if duplicated and (employee is None or duplicated.id != employee.id):
            flash("Ya existe un empleado con ese UID RFID.", "danger")
            return redirect(request.url)

        if employee is None:
            employee = Employee()
            db.session.add(employee)

        employee.name = name
        employee.document = document
        employee.uid_rfid = uid_rfid
        employee.position = position
        employee.active = active
        employee.restricted_access = restricted_access

        db.session.commit()
        flash("Empleado guardado correctamente.", "success")
        return redirect(url_for("employees"))

    @app.route("/empleados/<int:employee_id>/estado", methods=["POST"])
    @login_required
    def toggle_employee(employee_id: int):
        employee = db.session.get(Employee, employee_id)
        if employee is None:
            flash("Empleado no encontrado.", "warning")
            return redirect(url_for("employees"))

        employee.active = not employee.active
        db.session.commit()
        flash("Estado del empleado actualizado.", "success")
        return redirect(url_for("employees"))

    @app.route("/registros")
    @login_required
    def logs():
        result_filter = request.args.get("resultado", "").strip().upper()
        query = AccessLog.query
        if result_filter in {"PERMITIDO", "DENEGADO"}:
            query = query.filter_by(result=result_filter)
        items = query.order_by(AccessLog.created_at.desc()).limit(300).all()
        return render_template("logs.html", logs=items, result_filter=result_filter)

    @app.route("/api/dashboard")
    @login_required
    def api_dashboard():
        period = request.args.get("period", "day")
        selected_date = request.args.get("date", date.today().strftime("%Y-%m-%d"))
        employee_id = request.args.get("employee_id", type=int)
        restricted_date = request.args.get("restricted_date", date.today().strftime("%Y-%m-%d"))
        latest_logs = AccessLog.query.order_by(AccessLog.created_at.desc()).limit(8).all()
        restricted_logs = restricted_access_for_day(restricted_date)

        return jsonify({
            "metrics": metrics_for_today(),
            "latest_logs": [serialize_log(item) for item in latest_logs],
            "attendance_summary": worked_hours_summary(period, selected_date, employee_id),
            "restricted_logs": [serialize_log(item) for item in restricted_logs],
            "last_event_id": latest_logs[0].id if latest_logs else 0,
            "server_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        })

    @app.route("/api/registros")
    @login_required
    def api_logs():
        result_filter = request.args.get("resultado", "").strip().upper()
        query = AccessLog.query
        if result_filter in {"PERMITIDO", "DENEGADO"}:
            query = query.filter_by(result=result_filter)
        items = query.order_by(AccessLog.created_at.desc()).limit(300).all()
        return jsonify([serialize_log(item) for item in items])

    @app.template_filter("uidfmt")
    def uidfmt(value: str) -> str:
        return format_uid(value or "")

    @app.template_filter("eventlabel")
    def eventlabel(value: str) -> str:
        labels = {
            "entrada": "Entrada",
            "salida": "Salida",
            "acceso_area": "Acceso",
            "denegado_area": "Denegado",
            "denegado": "Denegado",
            "acceso": "Acceso",
        }
        return labels.get(value or "", "-")


def start_mqtt(app: Flask) -> Optional[mqtt.Client]:
    """Inicializa el cliente MQTT para recibir UID/JSON y responder al ESP32 con JSON."""
    if not app.config["MQTT_ENABLED"]:
        print("[MQTT] Deshabilitado por configuración.")
        return None

    client = mqtt.Client(client_id=app.config["MQTT_CLIENT_ID"], clean_session=True)

    if app.config["MQTT_USERNAME"]:
        client.username_pw_set(app.config["MQTT_USERNAME"], app.config["MQTT_PASSWORD"])

    if app.config["MQTT_TLS"]:
        ca_certs = app.config.get("MQTT_CA_CERT") or None
        certfile = app.config.get("MQTT_CLIENT_CERT") or None
        keyfile = app.config.get("MQTT_CLIENT_KEY") or None

        # Aunque MQTT_TLS_INSECURE=1, se siguen enviando certfile/keyfile.
        # Esto es necesario cuando Mosquitto tiene require_certificate=true.
        cert_reqs = ssl.CERT_NONE if app.config["MQTT_TLS_INSECURE"] else ssl.CERT_REQUIRED

        client.tls_set(
            ca_certs=ca_certs,
            certfile=certfile,
            keyfile=keyfile,
            cert_reqs=cert_reqs,
            tls_version=ssl.PROTOCOL_TLS_CLIENT,
        )
        client.tls_insecure_set(bool(app.config["MQTT_TLS_INSECURE"]))

        print("[MQTT] TLS habilitado")
        print(f"[MQTT] CA: {ca_certs or 'sin CA explícita'}")
        print(f"[MQTT] Cert cliente: {certfile or 'sin certificado cliente'}")
        print(f"[MQTT] Key cliente: {keyfile or 'sin llave cliente'}")

    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            topic_in = app.config["MQTT_TOPIC_IN"]
            client.subscribe(topic_in)
            print(f"[MQTT] Conectado a {app.config['MQTT_HOST']}:{app.config['MQTT_PORT']}")
            print(f"[MQTT] Suscrito a {topic_in}")
        else:
            print(f"[MQTT] Error de conexión. Código: {rc}")

    def on_disconnect(client, userdata, rc):
        print(f"[MQTT] Desconectado. Código: {rc}")

    def on_message(client, userdata, msg):
        payload_text = msg.payload.decode("utf-8", errors="ignore").strip()
        parsed = parse_mqtt_payload(payload_text)
        uid = str(parsed.get("uid", ""))
        device_id = parsed.get("device_id") or "esp32_access_01"
        incoming_door_state = parsed.get("door_state")

        print(f"[MQTT] Recibido en {msg.topic}: {payload_text}")

        with app.app_context():
            try:
                _allowed, _message, _log, response_payload = validate_and_register_uid(
                    uid,
                    source="mqtt",
                    device_id=str(device_id),
                    incoming_door_state=str(incoming_door_state) if incoming_door_state else None,
                    raw_payload=payload_text,
                )
                response_text = json.dumps(response_payload, ensure_ascii=False)
                client.publish(app.config["MQTT_TOPIC_OUT"], response_text)
                print(f"[MQTT] Respuesta enviada a {app.config['MQTT_TOPIC_OUT']}: {response_text}")
            except Exception as exc:
                db.session.rollback()
                print(f"[MQTT] Error procesando mensaje: {exc}")
                error_payload = {
                    "uid": format_uid(uid),
                    "authorized": False,
                    "door_state": "closed",
                    "device_id": str(device_id),
                    "message": "ERROR APLICACION",
                }
                client.publish(app.config["MQTT_TOPIC_OUT"], json.dumps(error_payload, ensure_ascii=False))

    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    client.on_message = on_message

    client.connect_async(app.config["MQTT_HOST"], app.config["MQTT_PORT"], keepalive=60)
    client.loop_start()
    return client


app = create_app()
mqtt_client = start_mqtt(app)


if __name__ == "__main__":
    # use_reloader=False evita crear dos clientes MQTT duplicados.
    app.run(
        host=app.config["APP_HOST"],
        port=app.config["APP_PORT"],
        debug=app.config["APP_DEBUG"],
        use_reloader=False,
    )
