# Instalación de la capa de aplicación en Raspberry Pi

Esta versión está preparada para correr en la Raspberry Pi y conectarse al Mosquitto local con MQTTS/TLS usando certificados en `~/mqtt_certs`.

## 1. Copiar proyecto a la Raspberry

Se recomienda dejarlo en:

```bash
/home/pi/iot_aplicacion_json_tls
```

Si tu usuario no es `pi`, usa:

```bash
~/iot_aplicacion_json_tls
```

## 2. Verificar certificados

En la Raspberry:

```bash
ls -l ~/mqtt_certs
```

La app espera estos tres archivos por defecto:

```text
~/mqtt_certs/ca.crt
~/mqtt_certs/client.crt
~/mqtt_certs/client.key
```

Si los archivos tienen otros nombres, edita `.env` y cambia:

```env
MQTT_CA_CERT=~/mqtt_certs/ca.crt
MQTT_CLIENT_CERT=~/mqtt_certs/client.crt
MQTT_CLIENT_KEY=~/mqtt_certs/client.key
```

## 3. Instalar dependencias

```bash
cd ~/iot_aplicacion_json_tls
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
nano .env
```

Configuración recomendada si Mosquitto está en la misma Raspberry:

```env
MQTT_ENABLED=1
MQTT_HOST=localhost
MQTT_PORT=8883
MQTT_TLS=1
MQTT_TLS_INSECURE=1
MQTT_CA_CERT=~/mqtt_certs/ca.crt
MQTT_CLIENT_CERT=~/mqtt_certs/client.crt
MQTT_CLIENT_KEY=~/mqtt_certs/client.key
```

`MQTT_TLS_INSECURE=1` evita problemas de validación de nombre del certificado cuando se conecta a `localhost`. La app igual envía el certificado y la llave del cliente.

## 4. Probar manualmente

```bash
source venv/bin/activate
python app.py
```

Desde el computador, abre:

```text
http://IP_DE_LA_RASPBERRY:5000
```

Credenciales iniciales:

```text
admin / admin123
```

## 5. Probar MQTT local

Terminal 1 en la Raspberry, para ver la respuesta de la app:

```bash
mosquitto_sub -h localhost -p 8883 \
  --cafile ~/mqtt_certs/ca.crt \
  --cert ~/mqtt_certs/client.crt \
  --key ~/mqtt_certs/client.key \
  --insecure \
  -t esp32/ordenes -v
```

Terminal 2 en la Raspberry, para simular la ESP32:

```bash
mosquitto_pub -h localhost -p 8883 \
  --cafile ~/mqtt_certs/ca.crt \
  --cert ~/mqtt_certs/client.crt \
  --key ~/mqtt_certs/client.key \
  --insecure \
  -t test/esp32 \
  -m '{"uid":"59 EF A0 03","authorized":false,"door_state":"closed","device_id":"esp32_access_01"}'
```

Respuesta esperada:

```json
{"uid":"59 EF A0 03","authorized":true,"door_state":"open","device_id":"esp32_access_01","message":"ACCESO PERMITIDO"}
```

## 6. Iniciar automáticamente con systemd

Puedes instalar el servicio con:

```bash
cd ~/iot_aplicacion_json_tls
chmod +x deploy/install_raspberry.sh
./deploy/install_raspberry.sh
```

Comandos útiles:

```bash
sudo systemctl status iot-app.service
sudo systemctl restart iot-app.service
sudo journalctl -u iot-app.service -f
```

Para verificar Mosquitto:

```bash
sudo systemctl status mosquitto
sudo journalctl -u mosquitto -f
```
