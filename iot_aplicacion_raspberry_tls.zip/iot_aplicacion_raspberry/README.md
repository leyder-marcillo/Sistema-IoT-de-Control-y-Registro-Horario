# Capa de aplicación - Sistema IoT de Control y Registro Horario

Aplicación web en Flask para la capa de aplicación del proyecto IoT. Recibe lecturas RFID desde MQTT, valida el UID contra la base de datos, registra el evento y responde al ESP32 con una orden JSON.

## Flujo MQTT

La ESP32 publica en el tópico `test/esp32`:

```json
{
  "uid": "59 EF A0 03",
  "authorized": false,
  "door_state": "closed",
  "device_id": "esp32_access_01"
}
```

La aplicación responde por `esp32/ordenes`:

```json
{
  "uid": "59 EF A0 03",
  "authorized": true,
  "door_state": "open",
  "device_id": "esp32_access_01",
  "message": "ACCESO PERMITIDO"
}
```

Si el UID no existe o el empleado está inactivo, responde:

```json
{
  "uid": "12 34 56 78",
  "authorized": false,
  "door_state": "closed",
  "device_id": "esp32_access_01",
  "message": "ACCESO DENEGADO"
}
```

La app también acepta temporalmente el formato anterior de la capa de red: un UID plano como `59EFA003`.

## Instalación en Windows con VSCode

```powershell
cd C:\iot_aplicacion
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
python app.py
```

Abrir:

```text
http://localhost:5000
```

Credenciales iniciales:

```text
Usuario: admin
Contraseña: admin123
```

## Configuración MQTT

Editar `.env`:

```env
MQTT_ENABLED=1
MQTT_HOST=192.168.137.198
MQTT_PORT=8883
MQTT_TOPIC_IN=test/esp32
MQTT_TOPIC_OUT=esp32/ordenes
MQTT_TLS=1
MQTT_TLS_INSECURE=1
```

Para usar MQTT sin TLS, cambiar:

```env
MQTT_PORT=1883
MQTT_TLS=0
```

## Tarjetas de prueba

Para una base de datos nueva se crean dos empleados/tarjetas:

- `59 EF A0 03` asociado a Johan.
- `A1 B2 C3 D4` como tarjeta 2 de prueba. Cambiar este UID desde la vista **Empleados** cuando tengan la segunda tarjeta real.

Si ya tenías una base de datos creada con la versión anterior, los empleados existentes se conservan. Para arrancar limpio con solo dos tarjetas, detén Flask y elimina el archivo de base de datos en `instance/iot_app.db`.

## Prueba desde Mosquitto en la Raspberry

Terminal 1 en Raspberry:

```bash
mosquitto_sub -h localhost -p 8883 -t esp32/ordenes -v --insecure
```

Terminal 2 en Raspberry:

```bash
mosquitto_pub -h localhost -p 8883 -t test/esp32 -m '{"uid":"59 EF A0 03","authorized":false,"door_state":"closed","device_id":"esp32_access_01"}' --insecure
```

Si el broker no usa TLS, usa `-p 1883` y quita `--insecure`.
