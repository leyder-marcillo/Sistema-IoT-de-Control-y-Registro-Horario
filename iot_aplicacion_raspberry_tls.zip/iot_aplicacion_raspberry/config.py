import os
from dotenv import load_dotenv

load_dotenv()


def env_bool(name: str, default: str = "0") -> bool:
    return os.getenv(name, default).strip().lower() in {"1", "true", "yes", "y", "on"}


def env_path(name: str, default: str = "") -> str:
    """Lee una ruta desde .env y expande ~ para que funcione en Raspberry/systemd."""
    value = os.getenv(name, default).strip()
    return os.path.abspath(os.path.expanduser(value)) if value else ""


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key")
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL", "sqlite:///iot_app.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    MQTT_ENABLED = env_bool("MQTT_ENABLED", "1")
    MQTT_HOST = os.getenv("MQTT_HOST", "localhost")
    MQTT_PORT = int(os.getenv("MQTT_PORT", "8883"))
    MQTT_TOPIC_IN = os.getenv("MQTT_TOPIC_IN", "test/esp32")
    MQTT_TOPIC_OUT = os.getenv("MQTT_TOPIC_OUT", "esp32/ordenes")
    MQTT_CLIENT_ID = os.getenv("MQTT_CLIENT_ID", "iot_app_backend")
    MQTT_USERNAME = os.getenv("MQTT_USERNAME", "")
    MQTT_PASSWORD = os.getenv("MQTT_PASSWORD", "")

    # TLS/MQTTS. Para el prototipo local se deja insecure=1 para aceptar certificado autofirmado.
    MQTT_TLS = env_bool("MQTT_TLS", "1")
    MQTT_TLS_INSECURE = env_bool("MQTT_TLS_INSECURE", "1")
    MQTT_CA_CERT = env_path("MQTT_CA_CERT", "")
    MQTT_CLIENT_CERT = env_path("MQTT_CLIENT_CERT", "")
    MQTT_CLIENT_KEY = env_path("MQTT_CLIENT_KEY", "")

    APP_HOST = os.getenv("APP_HOST", "0.0.0.0")
    APP_PORT = int(os.getenv("APP_PORT", "5000"))
    APP_DEBUG = env_bool("APP_DEBUG", "0")
