import json
import ssl
from datetime import date, datetime
from typing import Any, Dict, Optional, Tuple

import paho.mqtt.client as mqtt
from flask import Flask, flash, jsonify, redirect, render_template, request, url_for
from flask_login import LoginManager, UserMixin, current_user, login_required, login_user, logout_user
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func, text
from werkzeug.security import check_password_hash, generate_password_hash

from config import Config


db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = "login"

mqtt_client: Optional[mqtt.Client] = None


class SystemUser(UserMixin, db.Model):
    __tablename__ = "system_users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(30), default="admin", nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)


class Employee(db.Model):
    __tablename__ = "employees"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    document = db.Column(db.String(40), nullable=True)
    uid_rfid = db.Column(db.String(40), unique=True, nullable=False, index=True)
    position = db.Column(db.String(100), nullable=True)
    active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)

    logs = db.relationship("AccessLog", back_populates="employee", lazy=True)


class AccessLog(db.Model):
    __tablename__ = "access_logs"

    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey("employees.id"), nullable=True)
    uid_rfid = db.Column(db.String(40), nullable=False, index=True)
    result = db.Column(db.String(20), nullable=False)  # PERMITIDO / DENEGADO
    message = db.Column(db.String(120), nullable=False)
    source = db.Column(db.String(20), default="mqtt", nullable=False)  # mqtt / web
    device_id = db.Column(db.String(80), nullable=True)
    door_state = db.Column(db.String(30), nullable=True)
    raw_payload = db.Column(db.Text, nullable=True)
    response_payload = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False, index=True)

    employee = db.relationship("Employee", back_populates="logs")


@login_manager.user_loader
def load_user(user_id: str) -> Optional[SystemUser]:
    return db.session.get(SystemUser, int(user_id))


def normalize_uid(uid: str) -> str:
    """Normaliza el UID: quita espacios, guiones, dos puntos y pasa a mayúsculas."""
    return "".join(ch for ch in uid.strip().upper() if ch.isalnum())


def format_uid(uid_clean: str) -> str:
    """Devuelve el UID normalizado en grupos de dos caracteres: 59 EF A0 03."""
    uid_clean = normalize_uid(uid_clean)
    return " ".join(uid_clean[i:i + 2] for i in range(0, len(uid_clean), 2))


def parse_mqtt_payload(payload: str) -> Dict[str, Any]:
    """
    Acepta dos formatos:
    1) UID plano: 59EFA003
    2) JSON: {"uid":"59 EF A0 03", "device_id":"esp32_access_01", "door_state":"closed"}
    """
    payload = payload.strip()
    if not payload:
        return {"uid": "", "raw": payload, "is_json": False}

    try:
        data = json.loads(payload)
        if isinstance(data, dict):
            data["raw"] = payload
            data["is_json"] = True
            return data
    except json.JSONDecodeError:
        pass

    return {"uid": payload, "raw": payload, "is_json": False}


def build_response_payload(uid: str, allowed: bool, device_id: Optional[str]) -> Dict[str, Any]:
    """Construye la orden JSON que recibe el ESP32 por el tópico esp32/ordenes."""
    return {
        "uid": format_uid(uid),
        "authorized": bool(allowed),
        "door_state": "open" if allowed else "closed",
        "device_id": device_id or "esp32_access_01",
        "message": "ACCESO PERMITIDO" if allowed else "ACCESO DENEGADO",
    }


def validate_and_register_uid(
    uid: str,
    source: str = "mqtt",
    device_id: Optional[str] = None,
    incoming_door_state: Optional[str] = None,
    raw_payload: Optional[str] = None,
) -> Tuple[bool, str, AccessLog, Dict[str, Any]]:
    """Valida el UID contra la base de datos, registra el evento y retorna la respuesta JSON."""
    uid_clean = normalize_uid(uid)

    employee = Employee.query.filter_by(uid_rfid=uid_clean, active=True).first() if uid_clean else None
    allowed = employee is not None

    message = "ACCESO PERMITIDO" if allowed else "ACCESO DENEGADO"
    result = "PERMITIDO" if allowed else "DENEGADO"
    response_payload = build_response_payload(uid_clean or uid, allowed, device_id)

    log = AccessLog(
        employee_id=employee.id if employee else None,
        uid_rfid=uid_clean or "UID_VACIO",
        result=result,
        message=message,
        source=source,
        device_id=device_id,
        door_state=response_payload["door_state"],
        raw_payload=raw_payload,
        response_payload=json.dumps(response_payload, ensure_ascii=False),
    )
    db.session.add(log)
    db.session.commit()

    return allowed, message, log, response_payload


def publish_order(payload: Dict[str, Any]) -> None:
    """Publica la orden/respuesta hacia el ESP32 en formato JSON."""
    global mqtt_client
    if mqtt_client is None:
        print("[MQTT] Cliente no inicializado. No se pudo publicar la orden.")
        return

    topic_out = current_app_config("MQTT_TOPIC_OUT")
    message = json.dumps(payload, ensure_ascii=False)
    mqtt_client.publish(topic_out, message)
    print(f"[MQTT] Publicado en {topic_out}: {message}")


def current_app_config(key: str):
    from flask import current_app

    return current_app.config[key]


def create_app() -> Flask:
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    login_manager.init_app(app)

    register_routes(app)

    with app.app_context():
        db.create_all()
        ensure_schema_updates()
        seed_initial_data()

    return app


def ensure_schema_updates() -> None:
    """Agrega columnas nuevas si ya existía una base de datos de la versión anterior."""
    inspector_rows = db.session.execute(text("PRAGMA table_info(access_logs)")).fetchall()
    existing_columns = {row[1] for row in inspector_rows}

    migrations = {
        "device_id": "ALTER TABLE access_logs ADD COLUMN device_id VARCHAR(80)",
        "door_state": "ALTER TABLE access_logs ADD COLUMN door_state VARCHAR(30)",
        "raw_payload": "ALTER TABLE access_logs ADD COLUMN raw_payload TEXT",
        "response_payload": "ALTER TABLE access_logs ADD COLUMN response_payload TEXT",
    }

    for column, ddl in migrations.items():
        if column not in existing_columns:
            db.session.execute(text(ddl))

    db.session.commit()


def seed_initial_data() -> None:
    """Crea usuario administrador y dos tarjetas de prueba."""
    if SystemUser.query.count() == 0:
        admin = SystemUser(username="admin", role="admin")
        admin.set_password("admin123")
        db.session.add(admin)

    # Para nuevas bases de datos se crean solo dos tarjetas, como se planteó para la demo.
    if Employee.query.count() == 0:
        employees = [
            Employee(
                name="Johan David Rojas Martinez",
                document="",
                uid_rfid="59EFA003",
                position="Integrante del proyecto",
                active=True,
            ),
            Employee(
                name="Empleado Tarjeta 2",
                document="",
                uid_rfid="A1B2C3D4",
                position="Tarjeta de prueba - cambiar UID real",
                active=True,
            ),
        ]
        db.session.add_all(employees)

    db.session.commit()


def register_routes(app: Flask) -> None:
    @app.route("/")
    def index():
        if current_user.is_authenticated:
            return redirect(url_for("dashboard"))
        return redirect(url_for("login"))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            user = SystemUser.query.filter_by(username=username).first()

            if user and user.check_password(password):
                login_user(user)
                return redirect(url_for("dashboard"))

            flash("Usuario o contraseña incorrectos.", "danger")

        return render_template("login.html")

    @app.route("/logout")
    @login_required
    def logout():
        logout_user()
        return redirect(url_for("login"))

    @app.route("/dashboard")
    @login_required
    def dashboard():
        today_start = datetime.combine(date.today(), datetime.min.time())

        total_employees = Employee.query.count()
        active_employees = Employee.query.filter_by(active=True).count()
        allowed_today = AccessLog.query.filter(AccessLog.created_at >= today_start, AccessLog.result == "PERMITIDO").count()
        denied_today = AccessLog.query.filter(AccessLog.created_at >= today_start, AccessLog.result == "DENEGADO").count()
        latest_logs = AccessLog.query.order_by(AccessLog.created_at.desc()).limit(10).all()

        mqtt_info = {
            "host": app.config["MQTT_HOST"],
            "port": app.config["MQTT_PORT"],
            "topic_in": app.config["MQTT_TOPIC_IN"],
            "topic_out": app.config["MQTT_TOPIC_OUT"],
            "enabled": app.config["MQTT_ENABLED"],
            "tls": app.config["MQTT_TLS"],
        }

        return render_template(
            "dashboard.html",
            total_employees=total_employees,
            active_employees=active_employees,
            allowed_today=allowed_today,
            denied_today=denied_today,
            latest_logs=latest_logs,
            mqtt_info=mqtt_info,
        )

    @app.route("/simular", methods=["POST"])
    @login_required
    def simulate_uid():
        uid = request.form.get("uid", "")
        device_id = request.form.get("device_id", "esp32_access_01").strip() or "esp32_access_01"
        if not uid.strip():
            flash("Ingresa un UID para simular el evento.", "warning")
            return redirect(url_for("dashboard"))

        simulated_payload = {
            "uid": format_uid(uid),
            "authorized": False,
            "door_state": "closed",
            "device_id": device_id,
        }

        allowed, message, _log, response_payload = validate_and_register_uid(
            uid,
            source="web",
            device_id=device_id,
            incoming_door_state="closed",
            raw_payload=json.dumps(simulated_payload, ensure_ascii=False),
        )

        if mqtt_client is not None:
            publish_order(response_payload)

        flash(f"UID {format_uid(uid)}: {message}", "success" if allowed else "danger")
        return redirect(url_for("dashboard"))

    @app.route("/empleados")
    @login_required
    def employees():
        items = Employee.query.order_by(Employee.name.asc()).all()
        return render_template("employees.html", employees=items)

    @app.route("/empleados/nuevo", methods=["GET", "POST"])
    @login_required
    def new_employee():
        if request.method == "POST":
            return save_employee()
        return render_template("employee_form.html", employee=None)

    @app.route("/empleados/<int:employee_id>/editar", methods=["GET", "POST"])
    @login_required
    def edit_employee(employee_id: int):
        employee = db.session.get(Employee, employee_id)
        if employee is None:
            flash("Empleado no encontrado.", "warning")
            return redirect(url_for("employees"))

        if request.method == "POST":
            return save_employee(employee)

        return render_template("employee_form.html", employee=employee)

    def save_employee(employee: Optional[Employee] = None):
        name = request.form.get("name", "").strip()
        document = request.form.get("document", "").strip()
        uid_rfid = normalize_uid(request.form.get("uid_rfid", ""))
        position = request.form.get("position", "").strip()
        active = request.form.get("active") == "on"

        if not name or not uid_rfid:
            flash("El nombre y el UID RFID son obligatorios.", "danger")
            return redirect(request.url)

        duplicated = Employee.query.filter_by(uid_rfid=uid_rfid).first()
        if duplicated and (employee is None or duplicated.id != employee.id):
            flash("Ya existe un empleado con ese UID RFID.", "danger")
            return redirect(request.url)

        if employee is None:
            employee = Employee()
            db.session.add(employee)

        employee.name = name
        employee.document = document
        employee.uid_rfid = uid_rfid
        employee.position = position
        employee.active = active

        db.session.commit()
        flash("Empleado guardado correctamente.", "success")
        return redirect(url_for("employees"))

    @app.route("/empleados/<int:employee_id>/estado", methods=["POST"])
    @login_required
    def toggle_employee(employee_id: int):
        employee = db.session.get(Employee, employee_id)
        if employee is None:
            flash("Empleado no encontrado.", "warning")
            return redirect(url_for("employees"))

        employee.active = not employee.active
        db.session.commit()
        flash("Estado del empleado actualizado.", "success")
        return redirect(url_for("employees"))

    @app.route("/registros")
    @login_required
    def logs():
        result_filter = request.args.get("resultado", "").strip().upper()
        query = AccessLog.query
        if result_filter in {"PERMITIDO", "DENEGADO"}:
            query = query.filter_by(result=result_filter)
        items = query.order_by(AccessLog.created_at.desc()).limit(300).all()
        return render_template("logs.html", logs=items, result_filter=result_filter)

    @app.route("/api/registros")
    @login_required
    def api_logs():
        items = AccessLog.query.order_by(AccessLog.created_at.desc()).limit(50).all()
        return jsonify([
            {
                "id": item.id,
                "uid_rfid": format_uid(item.uid_rfid),
                "employee": item.employee.name if item.employee else "No registrado",
                "result": item.result,
                "message": item.message,
                "source": item.source,
                "device_id": item.device_id,
                "door_state": item.door_state,
                "response_payload": json.loads(item.response_payload) if item.response_payload else None,
                "created_at": item.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for item in items
        ])

    @app.template_filter("uidfmt")
    def uidfmt(value: str) -> str:
        return format_uid(value or "")


def start_mqtt(app: Flask) -> Optional[mqtt.Client]:
    """Inicializa el cliente MQTT para recibir UID/JSON y responder al ESP32 con JSON."""
    if not app.config["MQTT_ENABLED"]:
        print("[MQTT] Deshabilitado por configuración.")
        return None

    client = mqtt.Client(client_id=app.config["MQTT_CLIENT_ID"], clean_session=True)

    if app.config["MQTT_USERNAME"]:
        client.username_pw_set(app.config["MQTT_USERNAME"], app.config["MQTT_PASSWORD"])

    if app.config["MQTT_TLS"]:
        ca_certs = app.config.get("MQTT_CA_CERT") or None
        certfile = app.config.get("MQTT_CLIENT_CERT") or None
        keyfile = app.config.get("MQTT_CLIENT_KEY") or None

        # IMPORTANTE:
        # Aunque MQTT_TLS_INSECURE=1, se siguen enviando certfile/keyfile.
        # Esto es necesario cuando Mosquitto tiene require_certificate=true.
        cert_reqs = ssl.CERT_NONE if app.config["MQTT_TLS_INSECURE"] else ssl.CERT_REQUIRED

        client.tls_set(
            ca_certs=ca_certs,
            certfile=certfile,
            keyfile=keyfile,
            cert_reqs=cert_reqs,
            tls_version=ssl.PROTOCOL_TLS_CLIENT,
        )
        client.tls_insecure_set(bool(app.config["MQTT_TLS_INSECURE"]))

        print("[MQTT] TLS habilitado")
        print(f"[MQTT] CA: {ca_certs or 'sin CA explícita'}")
        print(f"[MQTT] Cert cliente: {certfile or 'sin certificado cliente'}")
        print(f"[MQTT] Key cliente: {keyfile or 'sin llave cliente'}")

    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            topic_in = app.config["MQTT_TOPIC_IN"]
            client.subscribe(topic_in)
            print(f"[MQTT] Conectado a {app.config['MQTT_HOST']}:{app.config['MQTT_PORT']}")
            print(f"[MQTT] Suscrito a {topic_in}")
        else:
            print(f"[MQTT] Error de conexión. Código: {rc}")

    def on_disconnect(client, userdata, rc):
        print(f"[MQTT] Desconectado. Código: {rc}")

    def on_message(client, userdata, msg):
        payload_text = msg.payload.decode("utf-8", errors="ignore").strip()
        parsed = parse_mqtt_payload(payload_text)
        uid = str(parsed.get("uid", ""))
        device_id = parsed.get("device_id") or "esp32_access_01"
        incoming_door_state = parsed.get("door_state")

        print(f"[MQTT] Recibido en {msg.topic}: {payload_text}")

        with app.app_context():
            try:
                _allowed, _message, _log, response_payload = validate_and_register_uid(
                    uid,
                    source="mqtt",
                    device_id=str(device_id),
                    incoming_door_state=str(incoming_door_state) if incoming_door_state else None,
                    raw_payload=payload_text,
                )
                response_text = json.dumps(response_payload, ensure_ascii=False)
                client.publish(app.config["MQTT_TOPIC_OUT"], response_text)
                print(f"[MQTT] Respuesta enviada a {app.config['MQTT_TOPIC_OUT']}: {response_text}")
            except Exception as exc:
                db.session.rollback()
                print(f"[MQTT] Error procesando mensaje: {exc}")
                error_payload = {
                    "uid": format_uid(uid),
                    "authorized": False,
                    "door_state": "closed",
                    "device_id": str(device_id),
                    "message": "ERROR APLICACION",
                }
                client.publish(app.config["MQTT_TOPIC_OUT"], json.dumps(error_payload, ensure_ascii=False))

    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    client.on_message = on_message

    client.connect_async(app.config["MQTT_HOST"], app.config["MQTT_PORT"], keepalive=60)
    client.loop_start()
    return client


app = create_app()
mqtt_client = start_mqtt(app)


if __name__ == "__main__":
    # use_reloader=False evita crear dos clientes MQTT duplicados.
    app.run(
        host=app.config["APP_HOST"],
        port=app.config["APP_PORT"],
        debug=app.config["APP_DEBUG"],
        use_reloader=False,
    )
